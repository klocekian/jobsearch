/**
 * Server the extension talks to.
 *
 * Previously a hardcoded constant, which meant testing against a local dev
 * server required editing this line and remembering to revert it before
 * committing. The manifest already grants localhost host permissions and the
 * server already allows CORS from localhost origins, so local development was
 * always intended — only the switch was missing.
 *
 * Stored per-browser in chrome.storage.local. Defaults to production, so an
 * existing install behaves exactly as before until someone changes it.
 */
const DEFAULT_API_BASE = "https://jobs.fieldlines.org";
const DEFAULT_LOCAL_BASE = "http://localhost:3000";
const API_BASE_KEY = "apiBase";
const LAST_LOCAL_KEY = "apiBaseLastLocal";
const RECENT_COLLAPSED_KEY = "recentCollapsed";
// Collapsed by default: the panel's job is clipping the current page, and the
// recent list is reference material. The "already saved" warning above it is
// never collapsed, so nothing load-bearing is hidden.
let recentCollapsed = true;
let API_BASE = DEFAULT_API_BASE;
// The last local server actually used, so someone on :3001 (because :3000 was
// taken) types it once and the Local button remembers it from then on.
let lastLocalBase = DEFAULT_LOCAL_BASE;

function isLocalBase(url) {
  try {
    const h = new URL(url).hostname;
    return h === "localhost" || h === "127.0.0.1" || h === "[::1]" || h === "0.0.0.0";
  } catch {
    return false;
  }
}

/** Trim, drop any trailing slash, and reject anything that isn't a valid http(s) origin. */
function normalizeApiBase(value) {
  const raw = (value || "").trim().replace(/\/+$/, "");
  if (!raw) return null;
  try {
    const u = new URL(raw);
    if (u.protocol !== "http:" && u.protocol !== "https:") return null;
    return u.origin;
  } catch {
    return null;
  }
}

async function loadApiBase() {
  try {
    const stored = await chrome.storage.local.get([API_BASE_KEY, LAST_LOCAL_KEY, RECENT_COLLAPSED_KEY]);
    if (typeof stored?.[RECENT_COLLAPSED_KEY] === "boolean") {
      recentCollapsed = stored[RECENT_COLLAPSED_KEY];
    }
    const normalized = normalizeApiBase(stored?.[API_BASE_KEY]);
    if (normalized) API_BASE = normalized;
    const rememberedLocal = normalizeApiBase(stored?.[LAST_LOCAL_KEY]);
    if (rememberedLocal) lastLocalBase = rememberedLocal;
  } catch {
    // Storage unavailable — fall back to the default rather than failing to start.
  }
  renderApiBase();
}

async function saveApiBase(value) {
  const normalized = normalizeApiBase(value);
  if (!normalized) return { ok: false, error: "Enter a full URL, e.g. http://localhost:3000" };
  API_BASE = normalized;
  const toStore = { [API_BASE_KEY]: normalized };
  if (isLocalBase(normalized)) {
    lastLocalBase = normalized;
    toStore[LAST_LOCAL_KEY] = normalized;
  }
  try {
    await chrome.storage.local.set(toStore);
  } catch (err) {
    const detail = err && err.message ? ` (${err.message})` : "";
    return { ok: false, error: `Couldn't save the setting${detail}.` };
  }
  renderApiBase();
  return { ok: true };
}

function renderApiBase() {
  const label = $("serverLabel");
  if (label) {
    label.textContent = API_BASE.replace(/^https?:\/\//, "");
    label.title = API_BASE;
  }
  const input = $("serverInput");
  if (input && !input.value) input.value = API_BASE;
  const localBtn = $("serverLocal");
  if (localBtn) {
    localBtn.textContent = `Use ${lastLocalBase.replace(/^https?:\/\//, "")}`;
    localBtn.style.display = API_BASE === lastLocalBase ? "none" : "inline-block";
  }
  const prodBtn = $("serverReset");
  if (prodBtn) prodBtn.style.display = API_BASE === DEFAULT_API_BASE ? "none" : "inline-block";
  const badge = $("serverBadge");
  if (badge) badge.style.display = API_BASE === DEFAULT_API_BASE ? "none" : "inline-block";
}


const $ = (id) => document.getElementById(id);
let pageData = null;
let fullPostingText = "";

async function clipPage() {
  $("loading").style.display = "block";
  $("form").style.display = "none";
  $("statusMsg").style.display = "none";
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error("No active tab");

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"],
    });

    pageData = results?.[0]?.result;
    if (!pageData?.text) throw new Error("No content extracted");

    if (pageData.hasSelection) {
      // Selected text — always use AI extraction since page structure isn't
      // available. Show the selection right away: it is the content the user
      // deliberately chose, and leaving the box empty while the AI call runs
      // (or silently fails) looks like the capture didn't work at all.
      fillForm({
        company: "", title: "", location: "", remoteType: "", salary: "",
        url: pageData.url, postingText: pageData.text,
      });
      $("loading").style.display = "none";
      $("form").style.display = "block";
      extractWithAI(pageData);
    } else {
      const quick = extractLocally(pageData);
      fillForm(quick);
      $("loading").style.display = "none";
      $("form").style.display = "block";

      const hasBasics = quick.company && quick.title;
      if (!hasBasics) {
        extractWithAI(pageData);
      }
    }
  } catch (err) {
    showStatus("error", err.message || "Failed to read the page.");
    $("loading").style.display = "none";
  }
}

async function loadRecentJobs() {
  const list = $("recentJobs");
  if (!list) return;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const currentUrl = tab?.url ?? "";

    const res = await fetch(`${API_BASE}/api/jobs?sort=created_at&order=desc`, { credentials: "include" });
    if (!res.ok) return;
    const data = await res.json();
    const allJobs = data.jobs ?? [];
    if (allJobs.length === 0) { list.style.display = "none"; return; }

    // Check if current page matches a saved job
    let matchHtml = "";
    if (currentUrl) {
      const normalizedUrl = currentUrl.split("?")[0].split("#")[0].replace(/\/$/, "").toLowerCase();
      const match = allJobs.find((j) => {
        if (!j.url) return false;
        const jUrl = j.url.split("?")[0].split("#")[0].replace(/\/$/, "").toLowerCase();
        return jUrl === normalizedUrl || currentUrl.includes(j.url) || (j.url && currentUrl.includes(j.url.split("?")[0]));
      });
      if (match) {
        matchHtml = `<div style="margin-bottom:10px;padding:8px 10px;background:#fef2f2;border:1px solid #fecaca;border-radius:8px;font-size:12px">` +
          `<div style="font-size:10px;font-weight:600;color:#dc2626;margin-bottom:3px">Already saved</div>` +
          `<a href="${API_BASE}/jobs/${match.id}" target="_blank" style="color:#1e293b;text-decoration:none;font-weight:600">${match.company || "—"}</a> · ${match.title || "—"}` +
          `<div style="margin-top:4px;font-size:10px;color:#64748b">Status: <strong>${match.status}</strong></div>` +
          `</div>`;
      }
    }

    const recent = allJobs.slice(0, 5);
    const caret = recentCollapsed ? "▸" : "▾";
    // The "already saved" warning is never collapsed — it is the one thing here
    // that changes what you do next. Only the recent list folds away.
    list.innerHTML = matchHtml +
      `<button type="button" id="recentToggle" aria-expanded="${!recentCollapsed}"` +
      ` style="display:flex;align-items:center;gap:4px;width:100%;background:none;border:none;padding:0;` +
      `font:inherit;font-size:11px;font-weight:600;color:#94a3b8;cursor:pointer;margin-bottom:6px;text-align:left">` +
      `<span id="recentCaret">${caret}</span> Recent clips` +
      `<span style="font-weight:400;color:#cbd5e1">(${recent.length})</span></button>` +
      `<div id="recentList" style="display:${recentCollapsed ? "none" : "block"}">` +
      recent.map((j) => `<a href="${API_BASE}/jobs/${j.id}" target="_blank" style="display:block;padding:4px 0;font-size:12px;color:#475569;text-decoration:none;line-height:1.3;border-bottom:1px solid #f1f5f9"><strong style="color:#1e293b">${j.company || "—"}</strong> · ${j.title || "—"}</a>`).join("") +
      `</div>`;

    // innerHTML was just replaced, so the listener is attached fresh each load.
    const toggle = $("recentToggle");
    if (toggle) {
      toggle.addEventListener("click", async () => {
        recentCollapsed = !recentCollapsed;
        const listEl = $("recentList");
        const caretEl = $("recentCaret");
        if (listEl) listEl.style.display = recentCollapsed ? "none" : "block";
        if (caretEl) caretEl.textContent = recentCollapsed ? "▸" : "▾";
        toggle.setAttribute("aria-expanded", String(!recentCollapsed));
        try {
          await chrome.storage.local.set({ [RECENT_COLLAPSED_KEY]: recentCollapsed });
        } catch { /* preference is a convenience; failing to persist is not worth an error */ }
      });
    }
  } catch { /* ignore */ }
}

const FILL_FIELD_LABELS = {
  first_name: "First name", last_name: "Last name", full_name: "Full name",
  email: "Email", phone: "Phone", address: "Address", city: "City", state: "State",
  current_title: "Title", current_company: "Company",
  linkedin: "LinkedIn", github: "GitHub", website: "Website", substack: "Substack",
  work_authorized: "Work auth", sponsorship_required: "Sponsorship",
};

async function loadFillFields() {
  const container = $("fillFields");
  if (!container) return;
  try {
    const res = await fetch(`${API_BASE}/api/profile/autofill`, { credentials: "include" });
    if (!res.ok) { container.innerHTML = `<p style="font-size:12px;color:#dc2626">Add a resume or fill in Application Fields on your Profile page.</p>`; return; }
    const data = await res.json();
    const keys = Object.keys(FILL_FIELD_LABELS);
    container.innerHTML = keys.map((key) => {
      const label = FILL_FIELD_LABELS[key];
      let value = data[key];
      if (value === true) value = "Yes";
      else if (value === false) value = "No";
      else value = value || "";
      return `<div class="field-row" data-value="${String(value).replace(/"/g, "&quot;")}" title="Click to copy">` +
        `<span class="field-label">${label}</span>` +
        `<span class="field-value ${value ? "" : "empty"}">${value || "—"}</span>` +
        `</div>`;
    }).join("");
    container.querySelectorAll(".field-row").forEach((row) => {
      row.addEventListener("click", () => {
        const v = row.getAttribute("data-value");
        if (!v) return;
        navigator.clipboard.writeText(v);
        const valEl = row.querySelector(".field-value");
        const orig = valEl.textContent;
        valEl.textContent = "Copied!";
        valEl.classList.add("copied-flash");
        setTimeout(() => { valEl.textContent = orig; valEl.classList.remove("copied-flash"); }, 1000);
      });
    });
  } catch { container.innerHTML = `<p style="font-size:12px;color:#94a3b8">Could not load profile.</p>`; }
}

async function init() {
  // Must complete before loadRecentJobs() or any clip: every request is built
  // from API_BASE.
  await loadApiBase();
  wireServerSetting();

  const clipBtn = $("clipBtn");
  if (clipBtn) {
    clipBtn.addEventListener("click", clipPage);
  } else {
    clipPage();
  }
  loadRecentJobs();

  // Tab switching
  const tabClip = $("tabClip");
  const tabFill = $("tabFill");
  const allTabs = [tabClip, tabFill].filter(Boolean);
  const allPanes = ["clipContent", "fillContent"];

  function switchTab(activeTab, activePane, onShow) {
    allTabs.forEach(t => t.classList.remove("active"));
    allPanes.forEach(p => { const el = $(p); if (el) el.style.display = "none"; });
    if (activeTab) activeTab.classList.add("active");
    const pane = $(activePane);
    if (pane) pane.style.display = "";
    if (onShow) onShow();
  }

  if (tabClip) tabClip.addEventListener("click", () => switchTab(tabClip, "clipContent"));
  if (tabFill) tabFill.addEventListener("click", () => switchTab(tabFill, "fillContent", loadFillFields));

  const refreshBtn = $("refreshBtn");
  if (refreshBtn) {
    refreshBtn.addEventListener("click", async () => {
      refreshBtn.disabled = true;
      refreshBtn.style.transition = "transform 0.5s";
      refreshBtn.style.transform = "rotate(360deg)";
      await Promise.all([
        loadRecentJobs(),
        $("fillContent")?.style.display !== "none" ? loadFillFields() : Promise.resolve(),
      ]);
      refreshBtn.disabled = false;
      setTimeout(() => { refreshBtn.style.transition = "none"; refreshBtn.style.transform = ""; }, 500);
    });
  }
}

function extractLocally(data) {
  const result = {
    company: "",
    title: "",
    location: "",
    remoteType: "",
    salary: "",
    url: data.url || "",
    postingText: data.text || "",
  };

  // From JSON-LD (most reliable)
  if (data.jsonLd) {
    const jl = data.jsonLd;
    result.title = jl.title || jl.name || "";
    if (jl.hiringOrganization) {
      result.company =
        typeof jl.hiringOrganization === "string"
          ? jl.hiringOrganization
          : jl.hiringOrganization.name || "";
    }
    if (jl.jobLocation) {
      const loc = Array.isArray(jl.jobLocation) ? jl.jobLocation[0] : jl.jobLocation;
      if (loc?.address) {
        const a = loc.address;
        result.location = [a.addressLocality, a.addressRegion].filter(Boolean).join(", ");
      }
    }
    if (jl.jobLocationType === "TELECOMMUTE") result.remoteType = "remote";
    if (jl.baseSalary) {
      const s = jl.baseSalary;
      if (s.value) {
        const v = s.value;
        const unit = s.currency === "USD" ? "$" : (s.currency || "$");
        if (v.minValue && v.maxValue) {
          result.salary = `${unit}${Math.round(v.minValue / 1000)}k–${unit}${Math.round(v.maxValue / 1000)}k`;
        } else if (v.value) {
          result.salary = `${unit}${Math.round(v.value / 1000)}k`;
        }
      }
    }
    if (jl.description) {
      result.postingText = jl.description
        .replace(/<[^>]+>/g, "\n")
        .replace(/&nbsp;/gi, " ")
        .replace(/&amp;/gi, "&")
        .replace(/&lt;/gi, "<")
        .replace(/&gt;/gi, ">")
        .replace(/&#39;|&apos;/gi, "'")
        .replace(/&quot;/gi, '"')
        .replace(/\n{3,}/g, "\n\n")
        .trim();
    }
  }

  // Title: h1 is usually the job title on posting pages
  if (!result.title && data.h1) {
    result.title = data.h1;
  }

  // Company: og:site_name is very reliable
  // A site extractor's company reading beats og:site_name, which on job-board
  // apps is the board itself ("LinkedIn") rather than the hiring company.
  if (!result.company && data.siteCompany) {
    result.company = data.siteCompany;
  }
  if (!result.company && data.ogCompany) {
    result.company = data.ogCompany;
  }

  // Fallback: parse company and title from page title or og:title
  if (!result.company || !result.title) {
    const candidates = [data.ogTitle, data.title].filter(Boolean);
    const patterns = [
      /^(.+?)\s+at\s+(.+?)(?:\s*[-–|·]|$)/i,
      /^(.+?)\s*[-–|]\s*(.+?)(?:\s*[-–|]|$)/,
      /^(.+?)\s*·\s*(.+)/,
    ];
    for (const text of candidates) {
      let matched = false;
      for (const p of patterns) {
        const m = text.match(p);
        if (m) {
          if (!result.title) result.title = m[1].trim();
          if (!result.company) result.company = m[2].trim();
          matched = true;
          break;
        }
      }
      if (matched) break;
    }
  }

  // Scan text for salary range
  if (!result.salary && data.text) {
    const salaryMatch = data.text.match(
      /\$[\d,]+(?:\.\d+)?(?:k)?\s*[-–—to]+\s*\$[\d,]+(?:\.\d+)?(?:k)?(?:\s*(?:per\s+)?(?:year|annually|yr|pa))?/i
    );
    if (salaryMatch) result.salary = salaryMatch[0];
  }

  // Scan for remote/hybrid/onsite
  if (!result.remoteType && data.text) {
    const t = data.text.slice(0, 3000).toLowerCase();
    if (/\b(?:fully\s+)?remote\b/.test(t)) result.remoteType = "remote";
    else if (/\bhybrid\b/.test(t)) result.remoteType = "hybrid";
    else if (/\bon[\s-]?site\b|\bin[\s-]?office\b/.test(t)) result.remoteType = "onsite";
  }

  // Scan for location from common patterns in first ~2000 chars
  if (!result.location && data.text) {
    const locMatch = data.text.slice(0, 2000).match(
      /(?:(?:San\s+Francisco|New\s+York|Los\s+Angeles|Mountain\s+View|Palo\s+Alto|San\s+Jose|Cupertino|Seattle|Austin|Chicago|Boston|Denver|Portland|Atlanta|Miami|Dallas|Houston|Phoenix|Minneapolis|Salt\s+Lake\s+City|Washington|San\s+Diego|Sunnyvale|Menlo\s+Park|Santa\s+Clara|Redwood\s+City|San\s+Mateo)[,\s]+(?:CA|NY|WA|TX|IL|MA|CO|OR|GA|FL|AZ|MN|UT|DC|[A-Z]{2}))/
    );
    if (locMatch) result.location = locMatch[0].trim();
  }

  return result;
}

function fillForm(data) {
  $("company").value = data.company || "";
  $("title").value = data.title || "";
  $("location").value = data.location || "";
  $("remoteType").value = data.remoteType || "";
  $("salary").value = data.salary || "";
  $("url").value = data.url || "";
  fullPostingText = data.postingText || "";
  $("postingPreview").value = fullPostingText;
  $("charCount").textContent = `${fullPostingText.length.toLocaleString()} chars`;
}

async function extractWithAI(data) {
  $("extractBtn").disabled = true;
  $("extractBtn").textContent = "Extracting…";
  try {
    const res = await fetch(`${API_BASE}/api/jobs/extract`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: data.text, url: data.url }),
    });
    if (!res.ok) {
      let msg = `AI extraction failed (${res.status}).`;
      try {
        const e = await res.json();
        if (e && e.error) msg = e.error;
      } catch {}
      const status = $("statusMsg");
      if (status) {
        status.textContent = `${msg} The captured text is still below — you can save it as is.`;
        status.style.display = "block";
      }
      $("extractBtn").textContent = "Re-extract with AI";
      $("extractBtn").disabled = false;
      return;
    }
    const result = await res.json();
    // Only overwrite fields that AI found and the user hasn't manually changed
    if (result.company && !$("company").value) $("company").value = result.company;
    if (result.jobTitle && !$("title").value) $("title").value = result.jobTitle;
    if (result.location && !$("location").value) $("location").value = result.location;
    if (result.remoteType && !$("remoteType").value) $("remoteType").value = result.remoteType;
    if (result.salaryText && !$("salary").value) $("salary").value = trimSalary(result.salaryText);
    // Only replace the preview if the user hasn't edited it — same rule the
    // other fields already follow.
    if (result.jobDescription && $("postingPreview").value === fullPostingText) {
      fullPostingText = result.jobDescription;
      $("postingPreview").value = fullPostingText;
      $("charCount").textContent = `${fullPostingText.length.toLocaleString()} chars`;
    }
    $("extractBtn").textContent = "Re-extract with AI";
    $("extractBtn").disabled = false;
  } catch {
    $("extractBtn").textContent = "Re-extract with AI";
    $("extractBtn").disabled = false;
  }
}

$("form").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("saveBtn").disabled = true;
  $("saveBtn").textContent = "Saving…";
  try {
    const res = await fetch(`${API_BASE}/api/jobs`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        company: $("company").value,
        title: $("title").value,
        url: $("url").value,
        location: $("location").value,
        remote_type: $("remoteType").value,
        salary_text: $("salary").value,
        posting_text: $("postingPreview").value || fullPostingText,
        source: "extension",
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      const msg = typeof data?.error === "string" ? data.error : JSON.stringify(data?.error ?? data);
      throw new Error(msg.length > 200 ? "Validation failed — check the fields and try again." : msg);
    }
    const verb = data.merged ? "Updated existing job" : "Saved";
    showStatus("success", `${verb}! <a href="${API_BASE}/jobs/${data.job.id}" target="_blank" style="color:inherit;text-decoration:underline">View job →</a>`);
    $("form").style.display = "none";
    $("saveBtn").disabled = false;
    $("saveBtn").textContent = "Save Job";
  } catch (err) {
    showStatus("error", err.message);
    $("saveBtn").disabled = false;
    $("saveBtn").textContent = "Save Job";
  }
});

$("extractBtn").addEventListener("click", () => {
  if (pageData) extractWithAI(pageData);
});

function trimSalary(text) {
  if (!text || text.length <= 100) return text;
  // Try to extract just a salary range like "$175,600 – $327,800"
  const m = text.match(/\$[\d,]+(?:\.\d+)?(?:k)?\s*[-–—to]+\s*\$[\d,]+(?:\.\d+)?(?:k)?/i);
  if (m) return m[0];
  // Truncate to first sentence
  const dot = text.indexOf(".");
  if (dot > 0 && dot < 150) return text.slice(0, dot + 1);
  return text.slice(0, 100);
}

async function fillApplication() {
  const fillBtn = $("fillBtn");
  if (!fillBtn) return;
  fillBtn.disabled = true;
  fillBtn.textContent = "Filling…";

  try {
    const res = await fetch(`${API_BASE}/api/profile/autofill`, { credentials: "include" });
    if (!res.ok) throw new Error("No profile data — add a resume on the Profile page first.");
    const profileData = await res.json();

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error("No active tab");

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      args: [profileData],
      func: autofillPage,
    });

    const count = results?.[0]?.result ?? 0;
    showStatus("success", `Filled ${count} field${count !== 1 ? "s" : ""}. Review before submitting.`);
  } catch (err) {
    showStatus("error", err.message || "Failed to fill form.");
  } finally {
    fillBtn.disabled = false;
    fillBtn.textContent = "Fill application fields";
  }
}

function autofillPage(data) {
  let filled = 0;

  const matchers = [
    { keys: ["first_name", "first name", "firstname", "given name", "fname", "preferred first name", "preferred name"], value: data.first_name },
    { keys: ["last_name", "last name", "lastname", "family name", "surname", "lname"], value: data.last_name },
    { keys: ["full_name", "full name", "legal full name", "legal name", "your name", "candidate name", "applicant name"], value: data.full_name },
    { keys: ["email", "e-mail", "email address"], value: data.email },
    { keys: ["phone", "phone number", "mobile", "telephone", "cell", "contact number"], value: data.phone },
    { keys: ["linkedin", "linkedin profile", "linkedin url"], value: data.linkedin },
    { keys: ["github", "github profile", "github url"], value: data.github },
    { keys: ["website", "portfolio", "personal website", "portfolio url", "personal site", "blog"], value: data.website || data.substack },
    { keys: ["city", "current city"], value: data.city },
    { keys: ["state", "province"], value: data.state },
    { keys: ["location", "current location", "address"], value: data.location },
    { keys: ["current title", "job title", "current role", "current position"], value: data.current_title },
    { keys: ["current company", "company", "current employer", "employer", "organization"], value: data.current_company },
  ];

  function normalize(str) {
    return (str || "").toLowerCase().replace(/[^a-z0-9]/g, " ").replace(/\s+/g, " ").trim();
  }

  function getFieldLabel(el) {
    const texts = [];
    if (el.id) {
      const label = document.querySelector("label[for='" + CSS.escape(el.id) + "']");
      if (label) texts.push(label.textContent);
    }
    const parentLabel = el.closest("label");
    if (parentLabel) texts.push(parentLabel.textContent);
    if (el.getAttribute("aria-label")) texts.push(el.getAttribute("aria-label"));
    if (el.getAttribute("aria-labelledby")) {
      const ref = document.getElementById(el.getAttribute("aria-labelledby"));
      if (ref) texts.push(ref.textContent);
    }
    // Walk up to find the nearest container with a label-like element
    let container = el.parentElement;
    for (let i = 0; i < 5 && container; i++) {
      const labelEl = container.querySelector("label, legend, [class*='label'], h3, h4");
      if (labelEl && labelEl !== el && !labelEl.contains(el)) {
        texts.push(labelEl.textContent);
        break;
      }
      container = container.parentElement;
    }
    // Check preceding sibling elements for label text
    let prev = el.previousElementSibling;
    for (let i = 0; i < 3 && prev; i++) {
      const tag = prev.tagName;
      if (tag === "LABEL" || tag === "P" || tag === "SPAN" || tag === "DIV" || tag === "H3" || tag === "H4") {
        const t = prev.textContent.trim();
        if (t.length > 0 && t.length < 100) { texts.push(t); break; }
      }
      prev = prev.previousElementSibling;
    }
    texts.push(el.name, el.placeholder, el.id);
    return texts.filter(Boolean).map(normalize).join(" ");
  }

  function setVal(el, value) {
    if (!value || !el || el.disabled || el.readOnly) return false;
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value");
    if (setter && setter.set) { setter.set.call(el, value); } else { el.value = value; }
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new Event("blur", { bubbles: true }));
    return true;
  }

  const fields = document.querySelectorAll('input[type="text"], input[type="email"], input[type="tel"], input[type="url"], input:not([type]), textarea');
  for (const el of fields) {
    const label = getFieldLabel(el);
    if (!label) continue;
    // "name" alone is too generic — only match if it's the only word or clearly a name field
    for (const matcher of matchers) {
      if (matcher.value && matcher.keys.some((k) => label.includes(k))) {
        if (setVal(el, matcher.value)) {
          filled++;
          el.style.outline = "2px solid #34d399";
          setTimeout(() => { el.style.outline = ""; }, 2000);
        }
        break;
      }
    }
  }

  // Yes/No buttons for work authorization
  function clickYesNo(questionWords, answer) {
    const buttons = document.querySelectorAll('button, [role="button"], [role="option"], label, input[type="radio"]');
    for (const btn of buttons) {
      const text = (btn.textContent || btn.value || "").trim().toLowerCase();
      const container = btn.closest("[class*='question'], [class*='field'], fieldset, [data-qa], [class*='group']");
      const question = (container?.textContent || "").toLowerCase();
      if (questionWords.some((w) => question.includes(w)) && text === answer) {
        btn.click();
        filled++;
        return;
      }
    }
  }

  clickYesNo(["eligible to work", "authorized to work", "legally authorized"], "yes");
  clickYesNo(["sponsorship", "visa sponsorship"], "no");

  return filled;
}

if ($("fillBtn")) {
  $("fillBtn").addEventListener("click", fillApplication);
}

function showStatus(type, msg) {
  const el = $("statusMsg") || $("fillStatus");
  if (!el) return;
  el.className = `status ${type}`;
  el.innerHTML = msg;
  el.style.display = "block";
  const fillStatus = $("fillStatus");
  if (fillStatus && $("fillContent")?.style.display !== "none") {
    fillStatus.className = `status ${type}`;
    fillStatus.innerHTML = msg;
    fillStatus.style.display = "block";
  }
}

function wireServerSetting() {
  const toggle = $("serverToggle");
  const row = $("serverRow");
  const input = $("serverInput");
  const saveBtn = $("serverSave");
  const resetBtn = $("serverReset");
  const status = $("serverStatus");
  if (!toggle || !row) return;

  toggle.addEventListener("click", () => {
    row.style.display = row.style.display === "none" ? "block" : "none";
  });

  const apply = async (value) => {
    const result = await saveApiBase(value);
    if (status) {
      status.textContent = result.ok ? "Saved. Reload the panel to reconnect." : result.error;
      status.style.display = "block";
    }
    if (result.ok) loadRecentJobs();
  };

  if (saveBtn && input) saveBtn.addEventListener("click", () => apply(input.value));
  if (input) {
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") { e.preventDefault(); apply(input.value); }
    });
  }
  if (resetBtn) {
    resetBtn.addEventListener("click", () => {
      if (input) input.value = DEFAULT_API_BASE;
      apply(DEFAULT_API_BASE);
    });
  }
  const localBtn = $("serverLocal");
  if (localBtn) {
    localBtn.addEventListener("click", () => {
      if (input) input.value = lastLocalBase;
      apply(lastLocalBase);
    });
  }
}

init();
